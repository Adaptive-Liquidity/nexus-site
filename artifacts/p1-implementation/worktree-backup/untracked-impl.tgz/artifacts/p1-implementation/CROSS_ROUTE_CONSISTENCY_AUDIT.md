# Cross-route semantic consistency audit

**Date:** 2026-07-29  
**Base HEAD:** `2ae7cf198f26449f71b4a916268dd32c40739ed3`

## Method

Compared claim IDs, statuses, limitations language, and trust vocabulary across:

- `src/content/claims-registry.json`
- `src/content/claim-relations.json`
- Maturity table/topology (`/maturity`)
- Claim graph (`/evidence/claims`)
- Observatory scenarios (`observatory-scenarios.ts`)
- Integration scenarios (`integration-scenarios.ts`)
- Benchmark fixture (`benchmark-fixture.ts`)
- Trust taxonomy (`trust-taxonomy.ts`)

## Registry ↔ relations

| Check | Result |
|-------|--------|
| Unique node IDs | PASS |
| Unique edge IDs | PASS |
| Edge endpoints resolve | PASS (`validate-claim-relations.mjs`) |
| Registry-linked status match | PASS |
| Stage 0 status IN_DEVELOPMENT | PASS |
| AEON memory IN_DEVELOPMENT | PASS |
| Change Gate IN_DEVELOPMENT | PASS |
| Signing anchors TARGET | PASS |
| Isolation/authority/capsules/explorer CURRENT | PASS |

## Doctrine

| Rule | Result |
|------|--------|
| Memory never expands authority | PASS (simulator + atlas barrier contract) |
| Rollback ≠ compensation | PASS (denial vs rollback fixtures) |
| Observation ≠ enforcement | PASS (trust taxonomy) |
| Signature ≠ production trust | PASS (lattice + observatory) |
| Benchmark fixtures non-citable | PASS (`CITABLE: NO`) |
| Destination Change Gate non-current | PASS |

## Cross-route name/status

Selecting `transactional-change-gate` on Claims and Maturity yields **In Integration / IN_DEVELOPMENT** consistently. No route paints it CURRENT.

## Residual notes

- Some header touch targets still surface Lighthouse target-size warnings on dense mobile nav; category score remains ≥95 after min-h-9 fixes on primary nav.
- Independent review F1–F3 were based on pre-fix screenshot misread / earlier package art; re-capture shows Stage 0 as **BLOCKING · IN INT.** and AEON as **IN INTEGRATION**.

## Verdict

**PASS** — no conflicting claim/maturity/trust/source chain detected.
